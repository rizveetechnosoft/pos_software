<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */
    'failed' => 'এই পরিচয়পত্র আমাদের রেকর্ডের সাথে মেলে না।',
    'throttle' => 'লগইন করার অনেক চেষ্টা। দয়া করে আবার চেষ্টা করুন: সেকেন্ড সেকেন্ড। ',

];


